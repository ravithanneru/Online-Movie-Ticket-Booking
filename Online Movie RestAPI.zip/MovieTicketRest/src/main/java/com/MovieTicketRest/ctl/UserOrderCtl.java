package com.MovieTicketRest.ctl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketRest.entity.UserOrderBillingEntity;
import com.MovieTicketRest.entity.UserOrderEntity;
import com.MovieTicketRest.entity.UserOrderResponse;
import com.MovieTicketRest.repository.MovieRepository;
import com.MovieTicketRest.repository.TheaterRepository;
import com.MovieTicketRest.repository.UserOrderBillingRepository;
import com.MovieTicketRest.repository.UserOrderRepository;

@RestController
public class UserOrderCtl {

	
	@Autowired
	private UserOrderRepository userOrderRepository;
	
	@Autowired
	private UserOrderBillingRepository userOrderBillingRepository;
	
	@Autowired
	private TheaterRepository theaterRepository;
	
	@Autowired
	private MovieRepository movieRepository;
	
	@PostMapping("/create-order")
	public String  createOrder(@RequestBody UserOrderEntity entity) {
		
		UserOrderBillingEntity billingInfo = userOrderBillingRepository.save(entity.getUserOrderBillingInfo());
		entity.setUserOrderBillingInfo(billingInfo);
		entity.setCreated_date(new Date());
		userOrderRepository.save(entity);
		
		return "Success";
	}
	
	@GetMapping("/userorders")
	public List<UserOrderResponse> getUserOrder(){
		List<UserOrderResponse> userOrderResponse = new ArrayList<UserOrderResponse>();
		
		List<UserOrderEntity> findAll = userOrderRepository.findAll();
		
		for(UserOrderEntity userorder :findAll) {
			
			UserOrderResponse userOrderinfo = new UserOrderResponse();
			
			userOrderinfo.setAmount(userorder.getOrderAmount());
			userOrderinfo.setPaidAmount(userorder.getPaidAmount());
			userOrderinfo.setPayStatus(userorder.isPayStatus());			
			userOrderinfo.setCreatedDate(userorder.getCreated_date());
			
			userOrderinfo.setUserOrderBillingEntity(userorder.getUserOrderBillingInfo());
			
			userOrderinfo.setTheaterEntity(theaterRepository.findById(userorder.getTheatorId()).get());
			userOrderinfo.setMovieEntity(movieRepository.findById(userorder.getMovieId()).get());
			userOrderResponse.add(userOrderinfo);
		}
		return userOrderResponse;
		
	}
	
	
	
	
	
	
	
}
