package com.MovieTicketRest.ctl;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketRest.repository.TheaterRepository;

@RestController
public class WelcomeCtl {


	
	@RequestMapping("/welcome")
	public String DisplayMsg() {
		
		return "Welcome To Online Movie Ticket API";
		
	}
	

}
