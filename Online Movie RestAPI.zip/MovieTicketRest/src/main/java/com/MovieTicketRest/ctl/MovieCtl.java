package com.MovieTicketRest.ctl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketRest.entity.MovieEntity;
import com.MovieTicketRest.entity.TheaterEntity;
import com.MovieTicketRest.repository.MovieRepository;

@RestController
public class MovieCtl {
	
	@Autowired
	private MovieRepository repository;
	
	@PostMapping("/saveMovie")
	public MovieEntity saveMovie(@RequestBody MovieEntity movie) {		
	MovieEntity saveMovie =	repository.save(movie);
	return saveMovie;
		
	}
	
	@GetMapping("/getMovie")
	public List<MovieEntity> movieList(){
		List<MovieEntity> findAll = repository.findAll();
		return findAll;
	}
	
	@PutMapping("/updateMovie")
	public MovieEntity updateMovie(@RequestBody MovieEntity movie){
		MovieEntity saveAndFlush = repository.saveAndFlush(movie);
		return saveAndFlush;
	}
	
	@DeleteMapping("/deleteMovie")
	public String deleteMovie(@RequestParam(value = "id", required = true) long id) {
		
		repository.deleteById(id);
		
		return "Success";
	}
	
	

}
