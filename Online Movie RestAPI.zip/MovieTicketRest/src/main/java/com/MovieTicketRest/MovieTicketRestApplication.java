package com.MovieTicketRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class MovieTicketRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketRestApplication.class, args);
	}

}
