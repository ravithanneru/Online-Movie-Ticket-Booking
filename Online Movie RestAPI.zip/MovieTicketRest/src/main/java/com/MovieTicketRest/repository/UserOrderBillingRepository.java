package com.MovieTicketRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketRest.entity.UserOrderBillingEntity;

public interface UserOrderBillingRepository extends JpaRepository<UserOrderBillingEntity, Long> {

}
