package com.MovieTicketRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketRest.entity.TheaterEntity;

public interface TheaterRepository extends JpaRepository<TheaterEntity, Long> {
	
	

}
