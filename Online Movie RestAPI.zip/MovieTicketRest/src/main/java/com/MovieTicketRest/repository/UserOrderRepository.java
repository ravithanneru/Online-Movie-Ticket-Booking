package com.MovieTicketRest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketRest.entity.UserOrderEntity;

public interface UserOrderRepository extends JpaRepository<UserOrderEntity, Long> {

}
